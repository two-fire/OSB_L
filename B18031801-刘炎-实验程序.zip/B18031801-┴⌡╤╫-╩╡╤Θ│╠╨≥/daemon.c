#include <stdio.h>
int main()
{
int pid;
pid = fork();
if (pid > 0)
{
while(1)
{
//nothing
}
}
else
{
printf("child pid = %d, ppid = %d\n", getpid(), getppid());
}
return 0;
}
