/*signal.c*/
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
void int_func(int sig);
int k;
/*定义循环变量*/
void int_func(int sig)
{
k = 0;
}
int main()
{
signal(SIGINT, int_func);
k = 1;
while (k == 1)
{
printf("Hello, world!\n");
}
printf("OK!\n");
printf("pid: %d,
ppid: %d \n", getpid(), getppid());
}
