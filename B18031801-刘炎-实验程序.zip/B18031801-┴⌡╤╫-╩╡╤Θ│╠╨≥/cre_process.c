#include <stdio.h>

int main()
{
	int pid;
	int i;

	pid = fork();

	if (pid == 0)
	{
		for (i = 0; i < 5; ++i)
		{
			printf("child %d , parentid %d\n", getpid(), getppid());
			sleep(2);
		}
	}
	else
	{
		for (i = 0; i < 5; ++i)
		{
			printf("parent %d , parentid %d\n", getpid(),getppid());
			sleep(2);
		}
	}
	wait(0);
	return 0;
}
